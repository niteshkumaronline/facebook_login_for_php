<?php
require_once('/init.php'); 

if($fbauth->login()){

header('Location:index.php');

}
else{

die('Error Logging In');
}



?>