<!-- Facebook Login-->
<?php //require_once __DIR__ . '/facebook-php-sdk-v4-5.0.0/src/Facebook/autoload.php'; 
require_once('/init.php');
//echo $fbauth->getAuthUrl();


  

?>
<!-- Facebook Login Ends # Required files, init.php, login.php, callback.php, logout.php-->
<!-- # Requires facebook SDK v4.5xx/\ HERE as DIR facebook-php-sdk-v4-5.0.0 -->
<!-- # Copyrights Casita Studios/Nitesh Kumar -->

	
<!--testing login with Facebook-->
<?php if($fbauth->isLogin()):   
echo $_SESSION['id_facebook']."</br>";
echo $_SESSION['name']."</br>";
echo $_SESSION['link']."</br>";
echo"<img src=\"https://graph.facebook.com/".$_SESSION['id_facebook']."/picture?width=428&height=428\"><br/>";
echo $_SESSION['email']."</br>";
echo $_SESSION['gender']."</br>";
//echo $_SESSION['birthday']."</br
//Permissions required for birthday
?>

<a href="logout.php">Logout</a> 

<?php else: ?>
Login with Facebook <a href="<?php echo $fbauth->getAuthUrl(); ?>"> Click Here</a> 

<?php endif; ?>	
	
	
<!--testing login with Facebook end-->
